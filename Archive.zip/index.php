<?php
// Disable Caching
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

$config_file = 'config.json';
if (!file_exists($config_file)) {
    die("Config file not found. Please create config.json");
}
$data = json_decode(file_get_contents($config_file), true);

// Helper function to convert hex to rgb for Tailwind opacity
function hex2rgb($hex) {
    $hex = str_replace("#", "", $hex);
    if(strlen($hex) == 3) {
        $r = hexdec(substr($hex,0,1).substr($hex,0,1));
        $g = hexdec(substr($hex,1,1).substr($hex,1,1));
        $b = hexdec(substr($hex,2,1).substr($hex,2,1));
    } else {
        $r = hexdec(substr($hex,0,2));
        $g = hexdec(substr($hex,2,2));
        $b = hexdec(substr($hex,4,2));
    }
    return "$r $g $b"; // Returns "R G B" format for Tailwind
}

$primaryRgb = hex2rgb($data['theme']['primaryColor']);
$secondaryRgb = hex2rgb($data['theme']['secondaryColor']);
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($data['hero']['title']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        background: '#020817',
                        foreground: '#f8fafc',
                        primary: 'rgb(var(--primary) / <alpha-value>)',
                        secondary: 'rgb(var(--secondary) / <alpha-value>)',
                        muted: { DEFAULT: '#1e293b', foreground: '#94a3b8' },
                        card: { DEFAULT: '#020817', foreground: '#f8fafc' },
                        border: '#1e293b',
                        input: '#1e293b',
                    },
                    fontFamily: {
                        display: ['Inter', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    <style>
        :root {
            --primary: <?php echo $primaryRgb; ?>;
            --secondary: <?php echo $secondaryRgb; ?>;
        }
        body { background-color: #020817; color: #f8fafc; }
        .glass-panel { background: rgba(255, 255, 255, 0.05); backdrop-filter: blur(10px); border: 1px solid rgba(255, 255, 255, 0.1); }
        .glass-card { background: rgba(255, 255, 255, 0.03); backdrop-filter: blur(10px); border: 1px solid rgba(255, 255, 255, 0.05); }
        .mesh-bg {
            background: radial-gradient(at 0% 0%, rgba(var(--primary), 0.15) 0px, transparent 50%),
                        radial-gradient(at 100% 0%, rgba(var(--secondary), 0.15) 0px, transparent 50%);
        }
        .text-glow { text-shadow: 0 0 20px rgba(var(--primary), 0.5); }
        /* Simple Animation Classes */
        .fade-in-up { opacity: 0; transform: translateY(20px); transition: opacity 0.6s ease-out, transform 0.6s ease-out; }
        .fade-in-up.visible { opacity: 1; transform: translateY(0); }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav class="fixed top-0 left-0 right-0 z-50 glass-panel border-b-0 border-white/5">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-20">
                <div class="flex-shrink-0 flex items-center gap-2">
                    <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center shadow-lg shadow-primary/20">
                        <i data-lucide="phone" class="w-5 h-5 text-white"></i>
                    </div>
                    <span class="text-xl font-bold text-white tracking-wide"><?php echo htmlspecialchars($data['navbar']['logoText']); ?></span>
                </div>
                <div class="hidden md:block">
                    <div class="ml-10 flex items-baseline space-x-8">
                        <?php foreach($data['navbar']['links'] as $link): ?>
                            <a href="<?php echo htmlspecialchars($link['href']); ?>" class="text-muted-foreground hover:text-white transition-colors"><?php echo htmlspecialchars($link['label']); ?></a>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="hidden md:flex items-center gap-4">
                    <a href="<?php echo htmlspecialchars($data['hero']['portalUrl']); ?>" class="text-muted-foreground hover:text-white hover:bg-white/5 px-4 py-2 rounded-md transition-colors">Login</a>
                    <a href="<?php echo htmlspecialchars($data['hero']['portalUrl']); ?>" class="bg-primary hover:bg-primary/90 text-white shadow-lg shadow-primary/25 px-4 py-2 rounded-md transition-all">Portal Access</a>
                </div>
                <!-- Mobile menu button -->
                <div class="md:hidden">
                    <button id="mobile-menu-btn" class="text-white p-2">
                        <i data-lucide="menu" class="w-6 h-6"></i>
                    </button>
                </div>
            </div>
        </div>
        <!-- Mobile Menu -->
        <div id="mobile-menu" class="hidden md:hidden glass-panel border-t border-white/5">
            <div class="px-2 pt-2 pb-3 space-y-1 sm:px-3">
                <?php foreach($data['navbar']['links'] as $link): ?>
                    <a href="<?php echo htmlspecialchars($link['href']); ?>" class="text-muted-foreground hover:text-white block px-3 py-2 rounded-md text-base font-medium"><?php echo htmlspecialchars($link['label']); ?></a>
                <?php endforeach; ?>
                <div class="mt-4 flex flex-col gap-2 p-3">
                    <a href="<?php echo htmlspecialchars($data['hero']['portalUrl']); ?>" class="w-full text-center border border-white/10 py-2 rounded-md text-white">Login</a>
                    <a href="<?php echo htmlspecialchars($data['hero']['portalUrl']); ?>" class="w-full text-center bg-primary py-2 rounded-md text-white">Portal Access</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
        <div class="absolute inset-0 mesh-bg"></div>
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 py-20 text-center">
            <div class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 mb-8 backdrop-blur-sm fade-in-up">
                <span class="flex h-2 w-2 rounded-full bg-primary animate-pulse"></span>
                <span class="text-sm font-medium text-muted-foreground">Next-Gen VoIP Solution</span>
            </div>
            <h1 class="text-5xl md:text-7xl lg:text-8xl font-extrabold tracking-tight mb-8 fade-in-up" style="transition-delay: 0.1s;">
                <span class="text-transparent bg-clip-text bg-gradient-to-b from-white to-white/70"><?php echo htmlspecialchars($data['hero']['title']); ?></span>
            </h1>
            <p class="text-xl md:text-2xl text-muted-foreground mb-12 max-w-2xl mx-auto leading-relaxed fade-in-up" style="transition-delay: 0.2s;">
                <?php echo htmlspecialchars($data['hero']['subtitle']); ?>
            </p>
            <div class="flex flex-col sm:flex-row items-center justify-center gap-4 fade-in-up" style="transition-delay: 0.3s;">
                <a href="<?php echo htmlspecialchars($data['hero']['portalUrl']); ?>" class="w-full sm:w-auto h-14 px-8 bg-gradient-to-r from-primary to-primary/80 hover:to-primary text-white shadow-lg shadow-primary/25 flex items-center justify-center rounded-xl font-semibold text-lg transition-all hover:-translate-y-1">
                    <?php echo htmlspecialchars($data['hero']['ctaText']); ?> <i data-lucide="arrow-right" class="ml-2 w-5 h-5"></i>
                </a>
                <a href="#pricing" class="w-full sm:w-auto h-14 px-8 border border-white/10 hover:bg-white/5 text-white flex items-center justify-center rounded-xl font-semibold text-lg transition-all">
                    View Pricing
                </a>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section id="features" class="py-24 relative z-10 bg-background">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center max-w-3xl mx-auto mb-20 fade-in-up">
                <h2 class="text-primary font-semibold tracking-wider uppercase mb-4 text-sm">Capabilities</h2>
                <h3 class="text-4xl md:text-5xl font-bold text-white mb-6">Powerful Features</h3>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php foreach($data['features'] as $feature): ?>
                <div class="group relative glass-card p-8 rounded-3xl overflow-hidden hover:border-primary/30 transition-all duration-300 fade-in-up">
                    <div class="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                    <div class="relative z-10">
                        <div class="w-14 h-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mb-6 group-hover:bg-primary/20 transition-colors">
                            <i data-lucide="<?php echo strtolower($feature['icon'] ?? 'zap'); ?>" class="w-7 h-7 text-primary"></i>
                        </div>
                        <h4 class="text-2xl font-bold text-white mb-4"><?php echo htmlspecialchars($feature['title']); ?></h4>
                        <p class="text-muted-foreground leading-relaxed"><?php echo htmlspecialchars($feature['description']); ?></p>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Pricing Section -->
    <section id="pricing" class="py-24 relative z-10 bg-card/30">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center max-w-3xl mx-auto mb-20 fade-in-up">
                <h2 class="text-primary font-semibold tracking-wider uppercase mb-4 text-sm">Flexible Pricing</h2>
                <h3 class="text-4xl md:text-5xl font-bold text-white mb-6">Choose Your Plan</h3>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch">
                <?php foreach($data['pricing'] as $index => $plan): 
                    $isPopular = ($index === 1); // Assuming 2nd plan is popular
                    $cardClass = $isPopular ? "bg-gradient-to-b from-primary/20 to-card border border-primary/50 shadow-2xl shadow-primary/20 transform md:-translate-y-4" : "glass-card";
                ?>
                <div class="relative rounded-3xl p-8 <?php echo $cardClass; ?> fade-in-up">
                    <?php if($isPopular): ?>
                        <div class="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2">
                            <span class="bg-primary text-white text-xs font-bold uppercase tracking-wider py-1 px-4 rounded-full">Most Popular</span>
                        </div>
                    <?php endif; ?>
                    <h4 class="text-2xl font-bold text-white mb-2"><?php echo htmlspecialchars($plan['name']); ?></h4>
                    <div class="mb-8"><span class="text-4xl font-extrabold text-white"><?php echo htmlspecialchars($plan['price']); ?></span></div>
                    <div class="space-y-4 mb-8">
                        <?php foreach($plan['features'] as $feat): ?>
                        <div class="flex items-start gap-3">
                            <div class="flex-shrink-0 w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mt-0.5">
                                <i data-lucide="check" class="w-3.5 h-3.5 text-primary"></i>
                            </div>
                            <span class="text-muted-foreground"><?php echo htmlspecialchars($feat); ?></span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <button onclick="window.open('https://wa.me/<?php echo $data['whatsappNumber']; ?>?text=I am interested in <?php echo urlencode($plan['name']); ?> plan', '_blank')" class="w-full h-12 rounded-xl text-base font-semibold <?php echo $isPopular ? 'bg-primary hover:bg-primary/90 text-white shadow-lg' : 'bg-white/10 hover:bg-white/20 text-white'; ?> transition-all flex items-center justify-center gap-2">
                        <i data-lucide="message-circle" class="w-5 h-5"></i> Inquire on WhatsApp
                    </button>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section id="faq" class="py-24 relative z-10 bg-background">
        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-16 fade-in-up">
                <h3 class="text-4xl font-bold text-white mb-4">Frequently Asked Questions</h3>
            </div>
            <div class="space-y-4">
                <?php foreach($data['faq'] as $index => $item): ?>
                <div class="glass-card border px-6 rounded-2xl overflow-hidden border-white/10 fade-in-up">
                    <button class="faq-btn flex w-full items-center justify-between py-6 text-left text-lg font-semibold text-white hover:text-primary transition-colors">
                        <?php echo htmlspecialchars($item['question']); ?>
                        <i data-lucide="chevron-down" class="w-5 h-5 transition-transform duration-200"></i>
                    </button>
                    <div class="faq-content hidden pb-6 text-muted-foreground text-base leading-relaxed">
                        <?php echo htmlspecialchars($item['answer']); ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Contact Form -->
    <section class="py-24 relative z-10 bg-card/50 border-t border-white/5">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
                <div class="fade-in-up">
                    <h2 class="text-4xl md:text-5xl font-bold text-white mb-6">Ready to Upgrade?</h2>
                    <p class="text-xl text-muted-foreground mb-8">Fill out the form and our team will get back to you.</p>
                </div>
                <div class="glass-panel p-8 md:p-10 rounded-3xl relative fade-in-up">
                    <form id="contactForm" action="api.php" method="POST" class="space-y-6">
                        <input type="hidden" name="action" value="register">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div class="space-y-2">
                                <label class="text-sm font-medium text-white/80">Full Name</label>
                                <input type="text" name="name" required class="w-full bg-background/50 border border-white/10 text-white h-12 px-3 rounded-xl focus:outline-none focus:border-primary">
                            </div>
                            <div class="space-y-2">
                                <label class="text-sm font-medium text-white/80">Email</label>
                                <input type="email" name="email" required class="w-full bg-background/50 border border-white/10 text-white h-12 px-3 rounded-xl focus:outline-none focus:border-primary">
                            </div>
                        </div>
                        <div class="space-y-2">
                            <label class="text-sm font-medium text-white/80">Phone</label>
                            <input type="text" name="phone" required class="w-full bg-background/50 border border-white/10 text-white h-12 px-3 rounded-xl focus:outline-none focus:border-primary">
                        </div>
                        <div class="space-y-2">
                            <label class="text-sm font-medium text-white/80">Message</label>
                            <textarea name="message" class="w-full bg-background/50 border border-white/10 text-white min-h-[120px] p-3 rounded-xl focus:outline-none focus:border-primary"></textarea>
                        </div>
                        <button type="submit" class="w-full h-14 text-lg bg-primary hover:bg-primary/90 text-white rounded-xl shadow-lg shadow-primary/20 transition-all">Request Access</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="border-t border-white/5 bg-background relative overflow-hidden py-12">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center gap-6">
            <div class="flex items-center gap-2">
                <div class="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
                    <i data-lucide="phone" class="w-4 h-4 text-primary"></i>
                </div>
                <span class="text-lg font-bold text-white"><?php echo htmlspecialchars($data['navbar']['logoText']); ?></span>
            </div>
            <div class="flex gap-6 text-sm text-muted-foreground">
                <?php foreach($data['footer']['links'] as $link): ?>
                    <a href="<?php echo htmlspecialchars($link['href']); ?>" class="hover:text-primary transition-colors"><?php echo htmlspecialchars($link['label']); ?></a>
                <?php endforeach; ?>
                <a href="admin.php" class="hover:text-primary transition-colors">Admin</a>
            </div>
            <p class="text-sm text-muted-foreground">© <?php echo date('Y'); ?> <?php echo htmlspecialchars($data['footer']['copyrightText']); ?></p>
        </div>
    </footer>

    <script>
        lucide.createIcons();

        // Mobile Menu Toggle
        document.getElementById('mobile-menu-btn').addEventListener('click', function() {
            document.getElementById('mobile-menu').classList.toggle('hidden');
        });

        // FAQ Accordion
        document.querySelectorAll('.faq-btn').forEach(button => {
            button.addEventListener('click', () => {
                const content = button.nextElementSibling;
                const icon = button.querySelector('i');
                content.classList.toggle('hidden');
                icon.style.transform = content.classList.contains('hidden') ? 'rotate(0deg)' : 'rotate(180deg)';
            });
        });

        // Scroll Animation (Intersection Observer)
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                }
            });
        }, { threshold: 0.1 });

        document.querySelectorAll('.fade-in-up').forEach((el) => observer.observe(el));

        // Form Submission
        document.getElementById('contactForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            const btn = this.querySelector('button[type="submit"]');
            const originalText = btn.innerText;
            btn.innerText = 'Sending...';
            btn.disabled = true;

            try {
                const formData = new FormData(this);
                const response = await fetch('api.php', { method: 'POST', body: formData });
                const result = await response.json();
                alert(result.message);
                if(result.success) this.reset();
            } catch (error) {
                alert('Error sending message');
            } finally {
                btn.innerText = originalText;
                btn.disabled = false;
            }
        });
    </script>
</body>
</html>
