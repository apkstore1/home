<?php
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'register') {
        $name = $_POST['name'] ?? '';
        $email = $_POST['email'] ?? '';
        $phone = $_POST['phone'] ?? '';
        $message = $_POST['message'] ?? '';

        // Load config to get recipient email
        $config = json_decode(file_get_contents('config.json'), true);
        $to = $config['emailSettings']['recipientEmail'];
        
        $subject = "New Registration Request from $name";
        $body = "Name: $name\nEmail: $email\nPhone: $phone\nMessage: $message";
        $headers = "From: noreply@yourdomain.com";

        // Send email (Ensure your server has mail configured)
        // mail($to, $subject, $body, $headers);

        // For now, just return success
        echo json_encode(['success' => true, 'message' => 'Registration submitted successfully! We will contact you shortly.']);
        exit;
    }
}

echo json_encode(['success' => false, 'message' => 'Invalid request']);
?>
