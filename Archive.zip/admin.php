<?php
session_start();
$config_file = 'config.json';

// 1. Handle Login
if (isset($_POST['login'])) {
    if ($_POST['username'] === 'admin' && $_POST['password'] === '1997mushariq') {
        $_SESSION['admin_logged_in'] = true;
        header("Location: admin.php");
        exit;
    } else {
        $error = "Invalid credentials";
    }
}

// 2. Handle Logout
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: admin.php");
    exit;
}

// 3. Handle Config Save
if (isset($_POST['save_config']) && isset($_SESSION['admin_logged_in'])) {
    // Read current config to preserve structure if needed, though we mostly overwrite
    $new_config = [
        'theme' => [
            'primaryColor' => $_POST['primaryColor'],
            'secondaryColor' => $_POST['secondaryColor']
        ],
        'hero' => [
            'title' => $_POST['heroTitle'],
            'subtitle' => $_POST['heroSubtitle'],
            'ctaText' => $_POST['heroCtaText'],
            'portalUrl' => $_POST['portalUrl']
        ],
        'navbar' => [
            'logoText' => $_POST['logoText'],
            'links' => isset($_POST['nav_links']) ? array_values($_POST['nav_links']) : []
        ],
        'footer' => [
            'copyrightText' => $_POST['copyrightText'],
            'links' => isset($_POST['footer_links']) ? array_values($_POST['footer_links']) : []
        ],
        'emailSettings' => [
            'recipientEmail' => $_POST['recipientEmail']
        ],
        'whatsappNumber' => $_POST['whatsappNumber'],
        'features' => [],
        'pricing' => [],
        'faq' => []
    ];

    // Process Features
    if (isset($_POST['features'])) {
        foreach ($_POST['features'] as $f) {
            if (!empty($f['title'])) {
                $new_config['features'][] = [
                    'id' => uniqid('f'),
                    'title' => $f['title'],
                    'description' => $f['description'],
                    'icon' => $f['icon']
                ];
            }
        }
    }

    // Process Pricing
    if (isset($_POST['pricing'])) {
        foreach ($_POST['pricing'] as $p) {
            if (!empty($p['name'])) {
                $plan = [
                    'id' => uniqid('p'),
                    'name' => $p['name'],
                    'price' => $p['price'],
                    'features' => []
                ];
                if (isset($p['features'])) {
                    foreach ($p['features'] as $pf) {
                        if (!empty($pf)) $plan['features'][] = $pf;
                    }
                }
                $new_config['pricing'][] = $plan;
            }
        }
    }

    // Process FAQ
    if (isset($_POST['faq'])) {
        foreach ($_POST['faq'] as $q) {
            if (!empty($q['question'])) {
                $new_config['faq'][] = [
                    'question' => $q['question'],
                    'answer' => $q['answer']
                ];
            }
        }
    }

    // Try to save
    if (file_put_contents($config_file, json_encode($new_config, JSON_PRETTY_PRINT))) {
        $success = "Website updated successfully!";
    } else {
        $error = "Error: Failed to write to config.json. Check permissions (chmod 777 config.json).";
    }
    
    // Always keep the form populated with what you just submitted, even if save failed
    $data = $new_config;

} else {
    if (file_exists($config_file)) {
        $json_content = file_get_contents($config_file);
        $data = json_decode($json_content, true);
        
        if (!$data) {
             $error = "Warning: config.json is empty or corrupted. Please restore it.";
             $data = []; // Prevent crash
        }
        
        if (!is_writable($config_file)) {
            $error = "Warning: config.json is not writable. Changes will not be saved. (Fix permissions)";
        }
    } else {
        die("Config file missing.");
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Calleey</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        body { background-color: #0f172a; color: #f8fafc; }
        .glass { background: rgba(30, 41, 59, 0.7); backdrop-filter: blur(10px); border: 1px solid rgba(255,255,255,0.1); }
        .input-field { width: 100%; background: #1e293b; border: 1px solid #334155; color: white; padding: 0.5rem 0.75rem; border-radius: 0.5rem; margin-top: 0.25rem; }
        .input-field:focus { outline: 2px solid #3b82f6; border-color: transparent; }
        .tab-btn.active { background-color: #3b82f6; color: white; }
        .remove-btn { color: #ef4444; cursor: pointer; }
        .remove-btn:hover { color: #dc2626; }
    </style>
</head>
<body class="min-h-screen flex flex-col font-sans">

<?php if (!isset($_SESSION['admin_logged_in'])): ?>
    <div class="flex-grow flex items-center justify-center p-4">
        <div class="w-full max-w-md p-8 rounded-2xl glass shadow-2xl">
            <div class="text-center mb-8">
                <div class="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <i data-lucide="lock" class="w-6 h-6 text-white"></i>
                </div>
                <h2 class="text-2xl font-bold">Admin Login</h2>
            </div>
            <?php if(isset($error)) echo "<div class='bg-red-500/20 text-red-200 p-3 rounded-lg mb-4 text-sm text-center'>$error</div>"; ?>
            <form method="POST" class="space-y-4">
                <div>
                    <label class="text-sm text-gray-400">Username</label>
                    <input type="text" name="username" class="input-field" required>
                </div>
                <div>
                    <label class="text-sm text-gray-400">Password</label>
                    <input type="password" name="password" class="input-field" required>
                </div>
                <button type="submit" name="login" class="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl font-semibold transition-all mt-4">Sign In</button>
            </form>
        </div>
    </div>
<?php else: ?>

    <!-- Admin Navbar -->
    <nav class="glass sticky top-0 z-50 border-b border-white/5">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <div class="flex items-center gap-2">
                    <i data-lucide="layout-dashboard" class="text-blue-500"></i>
                    <span class="font-bold text-lg">Website Builder</span>
                </div>
                <div class="flex gap-4 text-sm">
                    <a href="index.php" target="_blank" class="flex items-center gap-2 text-gray-400 hover:text-white transition-colors">
                        <i data-lucide="external-link" class="w-4 h-4"></i> View Site
                    </a>
                    <a href="?logout=true" class="flex items-center gap-2 text-red-400 hover:text-red-300 transition-colors">
                        <i data-lucide="log-out" class="w-4 h-4"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <main class="flex-grow max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
        
        <?php if(isset($success)): ?>
            <div id="alert" class="fixed bottom-4 right-4 bg-green-600 text-white px-6 py-4 rounded-xl shadow-2xl flex items-center gap-3 animate-bounce">
                <i data-lucide="check-circle"></i> <?php echo $success; ?>
            </div>
            <script>setTimeout(() => document.getElementById('alert').style.display = 'none', 3000);</script>
        <?php endif; ?>

        <form method="POST" class="flex flex-col lg:flex-row gap-8">
            
            <!-- Sidebar Tabs -->
            <div class="w-full lg:w-64 flex-shrink-0">
                <div class="glass rounded-xl p-2 sticky top-24 flex flex-row lg:flex-col gap-1 overflow-x-auto">
                    <button type="button" onclick="showTab('general')" class="tab-btn active text-left px-4 py-3 rounded-lg text-sm font-medium transition-colors flex items-center gap-3">
                        <i data-lucide="settings" class="w-4 h-4"></i> General
                    </button>
                    <button type="button" onclick="showTab('hero')" class="tab-btn text-left px-4 py-3 rounded-lg text-sm font-medium text-gray-400 hover:text-white transition-colors flex items-center gap-3">
                        <i data-lucide="image" class="w-4 h-4"></i> Hero Section
                    </button>
                    <button type="button" onclick="showTab('features')" class="tab-btn text-left px-4 py-3 rounded-lg text-sm font-medium text-gray-400 hover:text-white transition-colors flex items-center gap-3">
                        <i data-lucide="zap" class="w-4 h-4"></i> Features
                    </button>
                    <button type="button" onclick="showTab('pricing')" class="tab-btn text-left px-4 py-3 rounded-lg text-sm font-medium text-gray-400 hover:text-white transition-colors flex items-center gap-3">
                        <i data-lucide="credit-card" class="w-4 h-4"></i> Pricing
                    </button>
                    <button type="button" onclick="showTab('faq')" class="tab-btn text-left px-4 py-3 rounded-lg text-sm font-medium text-gray-400 hover:text-white transition-colors flex items-center gap-3">
                        <i data-lucide="help-circle" class="w-4 h-4"></i> FAQ
                    </button>
                    <button type="button" onclick="showTab('footer')" class="tab-btn text-left px-4 py-3 rounded-lg text-sm font-medium text-gray-400 hover:text-white transition-colors flex items-center gap-3">
                        <i data-lucide="layout-template" class="w-4 h-4"></i> Navbar & Footer
                    </button>
                </div>
            </div>

            <!-- Content Area -->
            <div class="flex-grow space-y-6">
                
                <!-- General Tab -->
                <div id="general" class="tab-content space-y-6">
                    <div class="glass p-6 rounded-2xl">
                        <h3 class="text-xl font-bold mb-4">Theme & Contact</h3>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="text-sm text-gray-400">Primary Color</label>
                                <div class="flex gap-2 mt-1">
                                    <input type="color" name="primaryColor" value="<?php echo $data['theme']['primaryColor']; ?>" class="h-10 w-14 bg-transparent border-0 cursor-pointer rounded">
                                    <input type="text" value="<?php echo $data['theme']['primaryColor']; ?>" class="input-field mt-0" readonly>
                                </div>
                            </div>
                            <div>
                                <label class="text-sm text-gray-400">Secondary Color</label>
                                <div class="flex gap-2 mt-1">
                                    <input type="color" name="secondaryColor" value="<?php echo $data['theme']['secondaryColor']; ?>" class="h-10 w-14 bg-transparent border-0 cursor-pointer rounded">
                                    <input type="text" value="<?php echo $data['theme']['secondaryColor']; ?>" class="input-field mt-0" readonly>
                                </div>
                            </div>
                            <div>
                                <label class="text-sm text-gray-400">WhatsApp Number</label>
                                <input type="text" name="whatsappNumber" value="<?php echo $data['whatsappNumber']; ?>" class="input-field">
                            </div>
                            <div>
                                <label class="text-sm text-gray-400">Recipient Email (for forms)</label>
                                <input type="email" name="recipientEmail" value="<?php echo $data['emailSettings']['recipientEmail']; ?>" class="input-field">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Hero Tab -->
                <div id="hero" class="tab-content hidden space-y-6">
                    <div class="glass p-6 rounded-2xl">
                        <h3 class="text-xl font-bold mb-4">Hero Section</h3>
                        <div class="space-y-4">
                            <div>
                                <label class="text-sm text-gray-400">Main Title</label>
                                <input type="text" name="heroTitle" value="<?php echo htmlspecialchars($data['hero']['title']); ?>" class="input-field text-lg font-bold">
                            </div>
                            <div>
                                <label class="text-sm text-gray-400">Subtitle</label>
                                <textarea name="heroSubtitle" class="input-field h-24"><?php echo htmlspecialchars($data['hero']['subtitle']); ?></textarea>
                            </div>
                            <div class="grid grid-cols-2 gap-4">
                                <div>
                                    <label class="text-sm text-gray-400">CTA Button Text</label>
                                    <input type="text" name="heroCtaText" value="<?php echo htmlspecialchars($data['hero']['ctaText']); ?>" class="input-field">
                                </div>
                                <div>
                                    <label class="text-sm text-gray-400">Portal URL</label>
                                    <input type="text" name="portalUrl" value="<?php echo htmlspecialchars($data['hero']['portalUrl']); ?>" class="input-field">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Features Tab -->
                <div id="features" class="tab-content hidden space-y-6">
                    <div class="glass p-6 rounded-2xl">
                        <div class="flex justify-between items-center mb-4">
                            <h3 class="text-xl font-bold">Features</h3>
                            <button type="button" onclick="addFeature()" class="bg-blue-600/20 text-blue-400 hover:bg-blue-600 hover:text-white px-3 py-1.5 rounded-lg text-sm transition-colors">+ Add Feature</button>
                        </div>
                        <div id="features-container" class="space-y-4">
                            <?php foreach($data['features'] as $idx => $feat): ?>
                            <div class="feature-item bg-white/5 p-4 rounded-xl border border-white/5 relative group">
                                <button type="button" onclick="this.parentElement.remove()" class="absolute top-2 right-2 text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"><i data-lucide="trash-2" class="w-4 h-4"></i></button>
                                <div class="grid grid-cols-1 md:grid-cols-12 gap-4">
                                    <div class="md:col-span-3">
                                        <label class="text-xs text-gray-500">Icon (Lucide Name)</label>
                                        <input type="text" name="features[<?php echo $idx; ?>][icon]" value="<?php echo $feat['icon']; ?>" class="input-field" placeholder="e.g. Shield">
                                    </div>
                                    <div class="md:col-span-9">
                                        <label class="text-xs text-gray-500">Title</label>
                                        <input type="text" name="features[<?php echo $idx; ?>][title]" value="<?php echo htmlspecialchars($feat['title']); ?>" class="input-field font-bold">
                                    </div>
                                    <div class="md:col-span-12">
                                        <label class="text-xs text-gray-500">Description</label>
                                        <textarea name="features[<?php echo $idx; ?>][description]" class="input-field h-20"><?php echo htmlspecialchars($feat['description']); ?></textarea>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <!-- Pricing Tab -->
                <div id="pricing" class="tab-content hidden space-y-6">
                    <div class="glass p-6 rounded-2xl">
                        <div class="flex justify-between items-center mb-4">
                            <h3 class="text-xl font-bold">Pricing Plans</h3>
                            <button type="button" onclick="addPricing()" class="bg-blue-600/20 text-blue-400 hover:bg-blue-600 hover:text-white px-3 py-1.5 rounded-lg text-sm transition-colors">+ Add Plan</button>
                        </div>
                        <div id="pricing-container" class="grid grid-cols-1 xl:grid-cols-2 gap-6">
                            <?php foreach($data['pricing'] as $idx => $plan): ?>
                            <div class="pricing-item bg-white/5 p-4 rounded-xl border border-white/5 relative group">
                                <button type="button" onclick="this.parentElement.remove()" class="absolute top-2 right-2 text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"><i data-lucide="trash-2" class="w-4 h-4"></i></button>
                                <div class="space-y-3">
                                    <div class="flex gap-4">
                                        <div class="flex-1">
                                            <label class="text-xs text-gray-500">Plan Name</label>
                                            <input type="text" name="pricing[<?php echo $idx; ?>][name]" value="<?php echo htmlspecialchars($plan['name']); ?>" class="input-field font-bold">
                                        </div>
                                        <div class="w-24">
                                            <label class="text-xs text-gray-500">Price</label>
                                            <input type="text" name="pricing[<?php echo $idx; ?>][price]" value="<?php echo htmlspecialchars($plan['price']); ?>" class="input-field">
                                        </div>
                                    </div>
                                    <div>
                                        <label class="text-xs text-gray-500">Features (One per line)</label>
                                        <div class="space-y-2" id="pricing-features-<?php echo $idx; ?>">
                                            <?php foreach($plan['features'] as $fIdx => $feat): ?>
                                                <div class="flex gap-2">
                                                    <input type="text" name="pricing[<?php echo $idx; ?>][features][]" value="<?php echo htmlspecialchars($feat); ?>" class="input-field mt-0">
                                                    <button type="button" onclick="this.parentElement.remove()" class="text-red-500 hover:text-red-400"><i data-lucide="x" class="w-4 h-4"></i></button>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                        <button type="button" onclick="addPricingFeature(<?php echo $idx; ?>)" class="text-xs text-blue-400 hover:text-blue-300 mt-2 flex items-center gap-1"><i data-lucide="plus" class="w-3 h-3"></i> Add Feature</button>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <!-- FAQ Tab -->
                <div id="faq" class="tab-content hidden space-y-6">
                    <div class="glass p-6 rounded-2xl">
                        <div class="flex justify-between items-center mb-4">
                            <h3 class="text-xl font-bold">FAQ</h3>
                            <button type="button" onclick="addFaq()" class="bg-blue-600/20 text-blue-400 hover:bg-blue-600 hover:text-white px-3 py-1.5 rounded-lg text-sm transition-colors">+ Add Question</button>
                        </div>
                        <div id="faq-container" class="space-y-4">
                            <?php foreach($data['faq'] as $idx => $item): ?>
                            <div class="faq-item bg-white/5 p-4 rounded-xl border border-white/5 relative group">
                                <button type="button" onclick="this.parentElement.remove()" class="absolute top-2 right-2 text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"><i data-lucide="trash-2" class="w-4 h-4"></i></button>
                                <div class="space-y-3">
                                    <div>
                                        <label class="text-xs text-gray-500">Question</label>
                                        <input type="text" name="faq[<?php echo $idx; ?>][question]" value="<?php echo htmlspecialchars($item['question']); ?>" class="input-field font-bold">
                                    </div>
                                    <div>
                                        <label class="text-xs text-gray-500">Answer</label>
                                        <textarea name="faq[<?php echo $idx; ?>][answer]" class="input-field h-20"><?php echo htmlspecialchars($item['answer']); ?></textarea>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <!-- Footer Tab -->
                <div id="footer" class="tab-content hidden space-y-6">
                    <div class="glass p-6 rounded-2xl">
                        <h3 class="text-xl font-bold mb-4">Navbar & Footer</h3>
                        <div class="space-y-6">
                            <div>
                                <label class="text-sm text-gray-400">Logo Text</label>
                                <input type="text" name="logoText" value="<?php echo htmlspecialchars($data['navbar']['logoText']); ?>" class="input-field">
                            </div>
                            <div>
                                <label class="text-sm text-gray-400">Copyright Text</label>
                                <input type="text" name="copyrightText" value="<?php echo htmlspecialchars($data['footer']['copyrightText']); ?>" class="input-field">
                            </div>
                            
                            <div class="border-t border-white/10 pt-4">
                                <div class="flex justify-between items-center mb-2">
                                    <label class="text-sm text-gray-400">Navbar Links</label>
                                    <button type="button" onclick="addLink('nav')" class="text-xs text-blue-400">+ Add Link</button>
                                </div>
                                <div id="nav-links-container" class="space-y-2">
                                    <?php foreach($data['navbar']['links'] as $idx => $link): ?>
                                    <div class="flex gap-2">
                                        <input type="text" name="nav_links[<?php echo $idx; ?>][label]" value="<?php echo htmlspecialchars($link['label']); ?>" placeholder="Label" class="input-field mt-0 flex-1">
                                        <input type="text" name="nav_links[<?php echo $idx; ?>][href]" value="<?php echo htmlspecialchars($link['href']); ?>" placeholder="Href" class="input-field mt-0 flex-1">
                                        <button type="button" onclick="this.parentElement.remove()" class="text-red-500"><i data-lucide="trash-2" class="w-4 h-4"></i></button>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>

                            <div class="border-t border-white/10 pt-4">
                                <div class="flex justify-between items-center mb-2">
                                    <label class="text-sm text-gray-400">Footer Links</label>
                                    <button type="button" onclick="addLink('footer')" class="text-xs text-blue-400">+ Add Link</button>
                                </div>
                                <div id="footer-links-container" class="space-y-2">
                                    <?php foreach($data['footer']['links'] as $idx => $link): ?>
                                    <div class="flex gap-2">
                                        <input type="text" name="footer_links[<?php echo $idx; ?>][label]" value="<?php echo htmlspecialchars($link['label']); ?>" placeholder="Label" class="input-field mt-0 flex-1">
                                        <input type="text" name="footer_links[<?php echo $idx; ?>][href]" value="<?php echo htmlspecialchars($link['href']); ?>" placeholder="Href" class="input-field mt-0 flex-1">
                                        <button type="button" onclick="this.parentElement.remove()" class="text-red-500"><i data-lucide="trash-2" class="w-4 h-4"></i></button>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <!-- Save Button (Sticky) -->
            <div class="fixed bottom-6 right-6 z-50">
                <button type="submit" name="save_config" class="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-full shadow-2xl shadow-blue-600/30 font-bold flex items-center gap-2 transition-all hover:scale-105">
                    <i data-lucide="save"></i> Save Changes
                </button>
            </div>

        </form>
    </main>

    <script>
        lucide.createIcons();

        function showTab(tabId) {
            document.querySelectorAll('.tab-content').forEach(el => el.classList.add('hidden'));
            document.getElementById(tabId).classList.remove('hidden');
            document.querySelectorAll('.tab-btn').forEach(el => el.classList.remove('active', 'bg-blue-600', 'text-white'));
            document.querySelectorAll('.tab-btn').forEach(el => el.classList.add('text-gray-400'));
            const btn = event.currentTarget;
            btn.classList.add('active');
            btn.classList.remove('text-gray-400');
        }

        function generateId() { return Date.now() + Math.random().toString(36).substr(2, 9); }

        function addFeature() {
            const idx = generateId();
            const html = `
                <div class="feature-item bg-white/5 p-4 rounded-xl border border-white/5 relative group animate-fade-in">
                    <button type="button" onclick="this.parentElement.remove()" class="absolute top-2 right-2 text-red-500"><i data-lucide="trash-2" class="w-4 h-4"></i></button>
                    <div class="grid grid-cols-1 md:grid-cols-12 gap-4">
                        <div class="md:col-span-3">
                            <label class="text-xs text-gray-500">Icon</label>
                            <input type="text" name="features[${idx}][icon]" class="input-field" placeholder="e.g. Shield">
                        </div>
                        <div class="md:col-span-9">
                            <label class="text-xs text-gray-500">Title</label>
                            <input type="text" name="features[${idx}][title]" class="input-field font-bold" placeholder="Feature Title">
                        </div>
                        <div class="md:col-span-12">
                            <label class="text-xs text-gray-500">Description</label>
                            <textarea name="features[${idx}][description]" class="input-field h-20" placeholder="Feature Description"></textarea>
                        </div>
                    </div>
                </div>`;
            document.getElementById('features-container').insertAdjacentHTML('beforeend', html);
            lucide.createIcons();
        }

        function addPricing() {
            const idx = generateId();
            const html = `
                <div class="pricing-item bg-white/5 p-4 rounded-xl border border-white/5 relative group">
                    <button type="button" onclick="this.parentElement.remove()" class="absolute top-2 right-2 text-red-500"><i data-lucide="trash-2" class="w-4 h-4"></i></button>
                    <div class="space-y-3">
                        <div class="flex gap-4">
                            <div class="flex-1">
                                <label class="text-xs text-gray-500">Plan Name</label>
                                <input type="text" name="pricing[${idx}][name]" class="input-field font-bold" placeholder="e.g. Starter">
                            </div>
                            <div class="w-24">
                                <label class="text-xs text-gray-500">Price</label>
                                <input type="text" name="pricing[${idx}][price]" class="input-field" placeholder="$10">
                            </div>
                        </div>
                        <div>
                            <label class="text-xs text-gray-500">Features</label>
                            <div class="space-y-2" id="pricing-features-${idx}">
                                <div class="flex gap-2">
                                    <input type="text" name="pricing[${idx}][features][]" class="input-field mt-0" placeholder="Feature 1">
                                </div>
                            </div>
                            <button type="button" onclick="addPricingFeature('${idx}')" class="text-xs text-blue-400 mt-2 flex items-center gap-1">+ Add Feature</button>
                        </div>
                    </div>
                </div>`;
            document.getElementById('pricing-container').insertAdjacentHTML('beforeend', html);
            lucide.createIcons();
        }

        function addPricingFeature(idx) {
            const html = `
                <div class="flex gap-2">
                    <input type="text" name="pricing[${idx}][features][]" class="input-field mt-0" placeholder="New Feature">
                    <button type="button" onclick="this.parentElement.remove()" class="text-red-500"><i data-lucide="x" class="w-4 h-4"></i></button>
                </div>`;
            document.getElementById(`pricing-features-${idx}`).insertAdjacentHTML('beforeend', html);
            lucide.createIcons();
        }

        function addFaq() {
            const idx = generateId();
            const html = `
                <div class="faq-item bg-white/5 p-4 rounded-xl border border-white/5 relative group">
                    <button type="button" onclick="this.parentElement.remove()" class="absolute top-2 right-2 text-red-500"><i data-lucide="trash-2" class="w-4 h-4"></i></button>
                    <div class="space-y-3">
                        <div>
                            <label class="text-xs text-gray-500">Question</label>
                            <input type="text" name="faq[${idx}][question]" class="input-field font-bold" placeholder="Question?">
                        </div>
                        <div>
                            <label class="text-xs text-gray-500">Answer</label>
                            <textarea name="faq[${idx}][answer]" class="input-field h-20" placeholder="Answer..."></textarea>
                        </div>
                    </div>
                </div>`;
            document.getElementById('faq-container').insertAdjacentHTML('beforeend', html);
            lucide.createIcons();
        }

        function addLink(type) {
            const idx = generateId();
            const name = type === 'nav' ? 'nav_links' : 'footer_links';
            const html = `
                <div class="flex gap-2">
                    <input type="text" name="${name}[${idx}][label]" placeholder="Label" class="input-field mt-0 flex-1">
                    <input type="text" name="${name}[${idx}][href]" placeholder="Href" class="input-field mt-0 flex-1">
                    <button type="button" onclick="this.parentElement.remove()" class="text-red-500"><i data-lucide="trash-2" class="w-4 h-4"></i></button>
                </div>`;
            document.getElementById(`${type}-links-container`).insertAdjacentHTML('beforeend', html);
            lucide.createIcons();
        }
    </script>
<?php endif; ?>
</body>
</html>
