import { useConfig } from "@/contexts/ConfigContext";
import { Phone, Menu, X } from "lucide-react";
import { useState } from "react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";

const Navbar = () => {
  const { config } = useConfig();
  const [mobileOpen, setMobileOpen] = useState(false);

  const allLinks = [
    ...config.navbar.links,
    ...config.pages.filter((p) => p.showInNav).map((p) => ({ id: p.id, label: p.title, href: `/page/${p.slug}` })),
  ];

  const renderLink = (link: { id: string; label: string; href: string }, onClick?: () => void) => {
    if (link.href.startsWith("/")) {
      return (
        <Link key={link.id} to={link.href} onClick={onClick} className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary">
          {link.label}
        </Link>
      );
    }
    return (
      <a key={link.id} href={link.href} onClick={onClick} className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary">
        {link.label}
      </a>
    );
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 border-b border-border/50 bg-background/80 backdrop-blur-xl">
      <div className="container mx-auto flex items-center justify-between px-4 py-4">
        <Link to="/" className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary glow-orange-sm">
            <Phone className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="text-xl font-bold text-foreground">
            {config.brand.name}
            <span className="ml-1 text-sm font-medium text-muted-foreground">{config.brand.tagline}</span>
          </span>
        </Link>

        <div className="hidden items-center gap-8 md:flex">
          {allLinks.map((link) => renderLink(link))}
          <div className="flex items-center gap-3">
            <a href={config.brand.portalUrl} className="rounded-lg border border-border px-4 py-2 text-sm font-medium text-foreground transition-all hover:border-primary/50 hover:text-primary">
              {config.navbar.loginText}
            </a>
            <a href={config.brand.portalUrl} className="rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90 glow-orange-sm">
              {config.navbar.registerText}
            </a>
          </div>
        </div>

        <button className="md:hidden text-foreground" onClick={() => setMobileOpen(!mobileOpen)}>
          {mobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="border-t border-border/50 bg-background/95 backdrop-blur-xl md:hidden"
          >
            <div className="container mx-auto flex flex-col gap-4 px-4 py-6">
              {allLinks.map((link) => renderLink(link, () => setMobileOpen(false)))}
              <div className="flex flex-col gap-3 pt-2">
                <a href={config.brand.portalUrl} className="rounded-lg border border-border px-4 py-2 text-center text-sm font-medium text-foreground">{config.navbar.loginText}</a>
                <a href={config.brand.portalUrl} className="rounded-lg bg-primary px-4 py-2 text-center text-sm font-semibold text-primary-foreground">{config.navbar.registerText}</a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;
