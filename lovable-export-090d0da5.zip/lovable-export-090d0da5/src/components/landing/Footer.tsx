import { useConfig } from "@/contexts/ConfigContext";
import { Phone } from "lucide-react";
import { Link } from "react-router-dom";

const Footer = () => {
  const { config } = useConfig();

  const allLinks = [
    ...config.footer.links,
    ...config.pages.filter((p) => p.showInFooter).map((p) => ({ id: p.id, label: p.title, href: `/page/${p.slug}` })),
  ];

  return (
    <footer className="border-t border-border bg-background py-12">
      <div className="container mx-auto px-4">
        <div className="flex flex-col items-center justify-between gap-6 md:flex-row">
          {config.footer.showBrand && (
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
                <Phone className="h-4 w-4 text-primary-foreground" />
              </div>
              <span className="font-bold text-foreground">{config.brand.name}</span>
            </div>
          )}
          <div className="flex flex-wrap gap-6">
            {allLinks.map((link) =>
              link.href.startsWith("/") ? (
                <Link key={link.id} to={link.href} className="text-sm text-muted-foreground hover:text-primary transition-colors">{link.label}</Link>
              ) : (
                <a key={link.id} href={link.href} className="text-sm text-muted-foreground hover:text-primary transition-colors">{link.label}</a>
              )
            )}
          </div>
          <p className="text-xs text-muted-foreground">{config.footer.copyrightText}</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
