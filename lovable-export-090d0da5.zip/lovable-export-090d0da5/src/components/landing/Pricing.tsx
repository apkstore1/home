import { useConfig } from "@/contexts/ConfigContext";
import { Check } from "lucide-react";
import { motion } from "framer-motion";

const Pricing = () => {
  const { config } = useConfig();

  return (
    <section id="pricing" className="relative py-24">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mb-16 text-center"
        >
          <h2 className="mb-4 text-3xl font-bold text-foreground md:text-4xl">{config.pricing.sectionTitle}</h2>
          <p className="mx-auto max-w-2xl text-muted-foreground">{config.pricing.sectionSubtitle}</p>
        </motion.div>

        <div className="grid gap-8 md:grid-cols-3">
          {config.pricing.cards.map((card, i) => (
            <motion.div
              key={card.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.15 }}
              className={`relative rounded-2xl border p-8 transition-all hover-glow ${
                card.popular
                  ? "border-primary/50 bg-gradient-card glow-orange"
                  : "border-border bg-gradient-card"
              }`}
            >
              {card.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-primary px-4 py-1 text-xs font-semibold text-primary-foreground">
                  Most Popular
                </div>
              )}
              <h3 className="mb-2 text-xl font-bold text-foreground">{card.title}</h3>
              <div className="mb-6">
                <span className="text-4xl font-extrabold text-gradient-orange">{card.price}</span>
                <span className="text-muted-foreground">{card.period}</span>
              </div>
              <ul className="mb-8 space-y-3">
                {card.features.map((feature, fi) => (
                  <li key={fi} className="flex items-center gap-3 text-sm text-muted-foreground">
                    <Check className="h-4 w-4 shrink-0 text-primary" />
                    {feature}
                  </li>
                ))}
              </ul>
              <a
                href={card.whatsappLink}
                target="_blank"
                rel="noopener noreferrer"
                className={`block w-full rounded-lg py-3 text-center text-sm font-semibold transition-all ${
                  card.popular
                    ? "bg-primary text-primary-foreground hover:opacity-90 glow-orange-sm"
                    : "border border-border text-foreground hover:border-primary/50 hover:text-primary"
                }`}
              >
                Choose Plan
              </a>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Pricing;
