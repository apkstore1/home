import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";

export interface PricingCard {
  id: string;
  title: string;
  price: string;
  period: string;
  features: string[];
  popular: boolean;
  whatsappLink: string;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
}

export interface FeatureItem {
  id: string;
  icon: string;
  title: string;
  description: string;
}

export interface NavLink {
  id: string;
  label: string;
  href: string;
}

export interface CustomPage {
  id: string;
  slug: string;
  title: string;
  content: string; // HTML/markdown content
  showInNav: boolean;
  showInFooter: boolean;
}

export interface SiteConfig {
  brand: {
    name: string;
    tagline: string;
    portalUrl: string;
  };
  hero: {
    title: string;
    highlight: string;
    subtitle: string;
    ctaPrimary: string;
    ctaSecondary: string;
  };
  features: {
    sectionTitle: string;
    sectionSubtitle: string;
    items: FeatureItem[];
  };
  pricing: {
    sectionTitle: string;
    sectionSubtitle: string;
    cards: PricingCard[];
  };
  faq: {
    sectionTitle: string;
    items: FAQItem[];
  };
  contact: {
    sectionTitle: string;
    sectionSubtitle: string;
    recipientEmail: string;
  };
  navbar: {
    links: NavLink[];
    loginText: string;
    registerText: string;
  };
  footer: {
    links: NavLink[];
    copyrightText: string;
    showBrand: boolean;
  };
  pages: CustomPage[];
  theme: {
    primaryHue: number;
    primarySaturation: number;
    primaryLightness: number;
  };
}

const defaultConfig: SiteConfig = {
  brand: {
    name: "Calleey",
    tagline: "VoIP Dialer",
    portalUrl: "#",
  },
  hero: {
    title: "Next-Gen VoIP",
    highlight: "Dialer Platform",
    subtitle: "Crystal-clear calls, intelligent routing, and enterprise-grade reliability. Power your business communications with Calleey.",
    ctaPrimary: "Get Started",
    ctaSecondary: "Watch Demo",
  },
  features: {
    sectionTitle: "Powerful Features",
    sectionSubtitle: "Everything you need for seamless VoIP communication",
    items: [
      { id: "1", icon: "Phone", title: "HD Voice Calls", description: "Crystal-clear audio quality with adaptive bitrate technology for uninterrupted conversations." },
      { id: "2", icon: "Shield", title: "Encrypted & Secure", description: "End-to-end encryption ensures your calls and data remain private and protected." },
      { id: "3", icon: "Zap", title: "Lightning Fast", description: "Ultra-low latency connections powered by our global edge network infrastructure." },
      { id: "4", icon: "BarChart", title: "Real-time Analytics", description: "Monitor call quality, usage patterns, and team performance with live dashboards." },
      { id: "5", icon: "Globe", title: "Global Coverage", description: "Connect to 150+ countries with local numbers and competitive international rates." },
      { id: "6", icon: "Headphones", title: "24/7 Support", description: "Dedicated support team available round the clock to assist with any issues." },
    ],
  },
  pricing: {
    sectionTitle: "Simple Pricing",
    sectionSubtitle: "Choose the plan that fits your business needs",
    cards: [
      {
        id: "1", title: "Starter", price: "$19", period: "/month",
        features: ["500 Minutes", "1 Phone Number", "Basic Analytics", "Email Support"],
        popular: false, whatsappLink: "https://wa.me/923328248163?text=I'm%20interested%20in%20the%20Starter%20plan",
      },
      {
        id: "2", title: "Professional", price: "$49", period: "/month",
        features: ["2000 Minutes", "5 Phone Numbers", "Advanced Analytics", "Priority Support", "Call Recording"],
        popular: true, whatsappLink: "https://wa.me/923328248163?text=I'm%20interested%20in%20the%20Professional%20plan",
      },
      {
        id: "3", title: "Enterprise", price: "$99", period: "/month",
        features: ["Unlimited Minutes", "25 Phone Numbers", "Custom Analytics", "Dedicated Manager", "API Access", "SLA Guarantee"],
        popular: false, whatsappLink: "https://wa.me/923328248163?text=I'm%20interested%20in%20the%20Enterprise%20plan",
      },
    ],
  },
  faq: {
    sectionTitle: "Frequently Asked Questions",
    items: [
      { id: "1", question: "How does Calleey VoIP work?", answer: "Calleey uses Voice over IP technology to route your calls through the internet, providing crystal-clear audio quality at a fraction of the cost of traditional phone lines." },
      { id: "2", question: "Can I keep my existing phone number?", answer: "Yes! We support number porting from most carriers. The process typically takes 1-2 business days to complete." },
      { id: "3", question: "Is there a free trial?", answer: "We offer a 14-day free trial on all plans with no credit card required. Experience the full power of Calleey risk-free." },
      { id: "4", question: "What hardware do I need?", answer: "No special hardware required. Calleey works on any device with an internet connection — desktop, laptop, tablet, or smartphone." },
      { id: "5", question: "How secure are my calls?", answer: "All calls are protected with AES-256 encryption. We comply with SOC 2 Type II and GDPR regulations to ensure maximum data protection." },
    ],
  },
  contact: {
    sectionTitle: "Get In Touch",
    sectionSubtitle: "Ready to transform your business communications? Send us a message.",
    recipientEmail: "Muhammad.mushariq.waada@gmail.com",
  },
  navbar: {
    links: [
      { id: "1", label: "Features", href: "#features" },
      { id: "2", label: "Pricing", href: "#pricing" },
      { id: "3", label: "FAQ", href: "#faq" },
      { id: "4", label: "Contact", href: "#contact" },
    ],
    loginText: "Login",
    registerText: "Register",
  },
  footer: {
    links: [
      { id: "1", label: "Features", href: "#features" },
      { id: "2", label: "Pricing", href: "#pricing" },
      { id: "3", label: "FAQ", href: "#faq" },
      { id: "4", label: "Contact", href: "#contact" },
    ],
    copyrightText: "© 2026 Calleey. All rights reserved.",
    showBrand: true,
  },
  pages: [],
  theme: {
    primaryHue: 33,
    primarySaturation: 100,
    primaryLightness: 50,
  },
};

interface ConfigContextType {
  config: SiteConfig;
  updateConfig: (newConfig: SiteConfig) => void;
  resetConfig: () => void;
}

const ConfigContext = createContext<ConfigContextType | undefined>(undefined);

const STORAGE_KEY = "calleey_site_config";

export const ConfigProvider = ({ children }: { children: ReactNode }) => {
  const [config, setConfig] = useState<SiteConfig>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          ...defaultConfig,
          ...parsed,
          navbar: { ...defaultConfig.navbar, ...(parsed.navbar || {}) },
          footer: { ...defaultConfig.footer, ...(parsed.footer || {}) },
          pages: parsed.pages || [],
        };
      }
    } catch {}
    return defaultConfig;
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
    const root = document.documentElement;
    root.style.setProperty("--primary", `${config.theme.primaryHue} ${config.theme.primarySaturation}% ${config.theme.primaryLightness}%`);
    root.style.setProperty("--ring", `${config.theme.primaryHue} ${config.theme.primarySaturation}% ${config.theme.primaryLightness}%`);
    root.style.setProperty("--glow-primary", `${config.theme.primaryHue} ${config.theme.primarySaturation}% ${config.theme.primaryLightness}%`);
  }, [config]);

  const updateConfig = (newConfig: SiteConfig) => setConfig(newConfig);
  const resetConfig = () => {
    localStorage.removeItem(STORAGE_KEY);
    setConfig(defaultConfig);
  };

  return (
    <ConfigContext.Provider value={{ config, updateConfig, resetConfig }}>
      {children}
    </ConfigContext.Provider>
  );
};

export const useConfig = () => {
  const context = useContext(ConfigContext);
  if (!context) throw new Error("useConfig must be used within ConfigProvider");
  return context;
};
