import { useConfig, SiteConfig, PricingCard, FAQItem, FeatureItem, NavLink, CustomPage } from "@/contexts/ConfigContext";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Save, RotateCcw, ArrowLeft, Palette, Type, CreditCard, HelpCircle, Mail, Layout, Plus, Trash2, Navigation, FileText, LogOut } from "lucide-react";
import { Link } from "react-router-dom";
import AdminLogin, { isAdminAuthenticated, logoutAdmin } from "@/components/admin/AdminLogin";

type Tab = "general" | "hero" | "features" | "pricing" | "faq" | "contact" | "navbar" | "footer" | "pages" | "theme";

const Admin = () => {
  const [authed, setAuthed] = useState(isAdminAuthenticated());

  if (!authed) return <AdminLogin onLogin={() => setAuthed(true)} />;

  return <AdminDashboard onLogout={() => { logoutAdmin(); setAuthed(false); }} />;
};

const AdminDashboard = ({ onLogout }: { onLogout: () => void }) => {
  const { config, updateConfig, resetConfig } = useConfig();
  const { toast } = useToast();
  const [draft, setDraft] = useState<SiteConfig>(JSON.parse(JSON.stringify(config)));
  const [tab, setTab] = useState<Tab>("general");

  const save = () => {
    updateConfig(draft);
    toast({ title: "Saved!", description: "All changes have been applied." });
  };

  const reset = () => {
    resetConfig();
    setDraft(JSON.parse(JSON.stringify(config)));
    toast({ title: "Reset", description: "Restored default configuration." });
    window.location.reload();
  };

  const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: "general", label: "General", icon: <Layout className="h-4 w-4" /> },
    { id: "hero", label: "Hero", icon: <Type className="h-4 w-4" /> },
    { id: "features", label: "Features", icon: <Layout className="h-4 w-4" /> },
    { id: "pricing", label: "Pricing", icon: <CreditCard className="h-4 w-4" /> },
    { id: "faq", label: "FAQ", icon: <HelpCircle className="h-4 w-4" /> },
    { id: "contact", label: "Contact", icon: <Mail className="h-4 w-4" /> },
    { id: "navbar", label: "Navbar", icon: <Navigation className="h-4 w-4" /> },
    { id: "footer", label: "Footer", icon: <Layout className="h-4 w-4" /> },
    { id: "pages", label: "Pages", icon: <FileText className="h-4 w-4" /> },
    { id: "theme", label: "Theme", icon: <Palette className="h-4 w-4" /> },
  ];

  const labelClass = "block text-xs font-medium text-muted-foreground mb-1.5";

  const updateDraft = (path: string, value: any) => {
    const newDraft = JSON.parse(JSON.stringify(draft));
    const keys = path.split(".");
    let obj = newDraft;
    for (let i = 0; i < keys.length - 1; i++) obj = obj[keys[i]];
    obj[keys[keys.length - 1]] = value;
    setDraft(newDraft);
  };

  // Pricing helpers
  const addPricingCard = () => {
    const c: PricingCard = { id: Date.now().toString(), title: "New Plan", price: "$0", period: "/month", features: ["Feature 1"], popular: false, whatsappLink: "https://wa.me/923328248163" };
    updateDraft("pricing.cards", [...draft.pricing.cards, c]);
  };
  const removePricingCard = (id: string) => updateDraft("pricing.cards", draft.pricing.cards.filter((c) => c.id !== id));
  const updateCardField = (i: number, field: string, value: any) => {
    const cards = [...draft.pricing.cards]; (cards[i] as any)[field] = value; updateDraft("pricing.cards", cards);
  };

  // FAQ helpers
  const addFAQ = () => updateDraft("faq.items", [...draft.faq.items, { id: Date.now().toString(), question: "New Question?", answer: "Answer here." }]);
  const removeFAQ = (id: string) => updateDraft("faq.items", draft.faq.items.filter((f) => f.id !== id));
  const updateFAQField = (i: number, field: string, value: string) => {
    const items = [...draft.faq.items]; (items[i] as any)[field] = value; updateDraft("faq.items", items);
  };

  // Feature helpers
  const addFeature = () => updateDraft("features.items", [...draft.features.items, { id: Date.now().toString(), icon: "Phone", title: "New Feature", description: "Description" }]);
  const removeFeature = (id: string) => updateDraft("features.items", draft.features.items.filter((f) => f.id !== id));
  const updateFeatureField = (i: number, field: string, value: any) => {
    const items = [...draft.features.items]; (items[i] as any)[field] = value; updateDraft("features.items", items);
  };

  // NavLink helpers
  const addNavLink = (section: "navbar" | "footer") => {
    const link: NavLink = { id: Date.now().toString(), label: "New Link", href: "#" };
    updateDraft(`${section}.links`, [...(draft as any)[section].links, link]);
  };
  const removeNavLink = (section: "navbar" | "footer", id: string) => {
    updateDraft(`${section}.links`, (draft as any)[section].links.filter((l: NavLink) => l.id !== id));
  };
  const updateNavLink = (section: "navbar" | "footer", i: number, field: string, value: string) => {
    const links = [...(draft as any)[section].links]; links[i][field] = value; updateDraft(`${section}.links`, links);
  };

  // Page helpers
  const addPage = () => {
    const page: CustomPage = { id: Date.now().toString(), slug: `page-${Date.now()}`, title: "New Page", content: "<p>Page content here...</p>", showInNav: false, showInFooter: false };
    setDraft({ ...draft, pages: [...draft.pages, page] });
  };
  const removePage = (id: string) => setDraft({ ...draft, pages: draft.pages.filter((p) => p.id !== id) });
  const updatePageField = (i: number, field: string, value: any) => {
    const pages = [...draft.pages]; (pages[i] as any)[field] = value; setDraft({ ...draft, pages });
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Top bar */}
      <div className="sticky top-0 z-50 border-b border-border bg-background/90 backdrop-blur-xl">
        <div className="container mx-auto flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-4">
            <Link to="/" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors">
              <ArrowLeft className="h-4 w-4" /> Back to Site
            </Link>
            <span className="text-sm font-bold text-foreground">Admin Panel</span>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={onLogout} className="flex items-center gap-2 rounded-lg border border-border px-4 py-2 text-xs font-medium text-muted-foreground hover:text-foreground transition-colors">
              <LogOut className="h-3.5 w-3.5" /> Logout
            </button>
            <button onClick={reset} className="flex items-center gap-2 rounded-lg border border-border px-4 py-2 text-xs font-medium text-muted-foreground hover:text-destructive hover:border-destructive transition-colors">
              <RotateCcw className="h-3.5 w-3.5" /> Reset
            </button>
            <button onClick={save} className="flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-xs font-semibold text-primary-foreground glow-orange-sm hover:opacity-90 transition-all">
              <Save className="h-3.5 w-3.5" /> Save Changes
            </button>
          </div>
        </div>
      </div>

      <div className="container mx-auto flex gap-6 px-4 py-8">
        {/* Sidebar */}
        <div className="hidden w-52 shrink-0 md:block">
          <nav className="sticky top-20 space-y-1">
            {tabs.map((t) => (
              <button key={t.id} onClick={() => setTab(t.id)}
                className={`flex w-full items-center gap-3 rounded-lg px-4 py-2.5 text-sm transition-colors ${tab === t.id ? "bg-primary/10 text-primary font-medium" : "text-muted-foreground hover:text-foreground hover:bg-muted/50"}`}>
                {t.icon} {t.label}
              </button>
            ))}
          </nav>
        </div>

        {/* Mobile tabs */}
        <div className="fixed bottom-0 left-0 right-0 z-50 flex overflow-x-auto border-t border-border bg-background p-2 md:hidden">
          {tabs.map((t) => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`flex shrink-0 flex-col items-center gap-1 px-3 py-2 text-xs ${tab === t.id ? "text-primary" : "text-muted-foreground"}`}>
              {t.icon} {t.label}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 max-w-3xl space-y-6 pb-20 md:pb-8">
          {tab === "general" && (
            <Section title="General Settings">
              <Field label="Brand Name" value={draft.brand.name} onChange={(v) => updateDraft("brand.name", v)} />
              <Field label="Tagline" value={draft.brand.tagline} onChange={(v) => updateDraft("brand.tagline", v)} />
              <Field label="Portal URL (Login/Register)" value={draft.brand.portalUrl} onChange={(v) => updateDraft("brand.portalUrl", v)} />
            </Section>
          )}

          {tab === "hero" && (
            <Section title="Hero Section">
              <Field label="Title" value={draft.hero.title} onChange={(v) => updateDraft("hero.title", v)} />
              <Field label="Highlighted Text" value={draft.hero.highlight} onChange={(v) => updateDraft("hero.highlight", v)} />
              <Field label="Subtitle" value={draft.hero.subtitle} onChange={(v) => updateDraft("hero.subtitle", v)} textarea />
              <Field label="Primary CTA" value={draft.hero.ctaPrimary} onChange={(v) => updateDraft("hero.ctaPrimary", v)} />
              <Field label="Secondary CTA" value={draft.hero.ctaSecondary} onChange={(v) => updateDraft("hero.ctaSecondary", v)} />
            </Section>
          )}

          {tab === "features" && (
            <Section title="Features" action={<AddBtn onClick={addFeature} />}>
              <Field label="Section Title" value={draft.features.sectionTitle} onChange={(v) => updateDraft("features.sectionTitle", v)} />
              <Field label="Section Subtitle" value={draft.features.sectionSubtitle} onChange={(v) => updateDraft("features.sectionSubtitle", v)} />
              {draft.features.items.map((item, i) => (
                <ItemCard key={item.id} label={`Feature ${i + 1}`} onRemove={() => removeFeature(item.id)}>
                  <Field label="Icon (Phone, Shield, Zap, BarChart, Globe, Headphones)" value={item.icon} onChange={(v) => updateFeatureField(i, "icon", v)} />
                  <Field label="Title" value={item.title} onChange={(v) => updateFeatureField(i, "title", v)} />
                  <Field label="Description" value={item.description} onChange={(v) => updateFeatureField(i, "description", v)} textarea />
                </ItemCard>
              ))}
            </Section>
          )}

          {tab === "pricing" && (
            <Section title="Pricing Cards" action={<AddBtn label="Add Card" onClick={addPricingCard} />}>
              <Field label="Section Title" value={draft.pricing.sectionTitle} onChange={(v) => updateDraft("pricing.sectionTitle", v)} />
              <Field label="Section Subtitle" value={draft.pricing.sectionSubtitle} onChange={(v) => updateDraft("pricing.sectionSubtitle", v)} />
              {draft.pricing.cards.map((card, i) => (
                <ItemCard key={card.id} label={card.title} onRemove={() => removePricingCard(card.id)}>
                  <Field label="Title" value={card.title} onChange={(v) => updateCardField(i, "title", v)} />
                  <Field label="Price" value={card.price} onChange={(v) => updateCardField(i, "price", v)} />
                  <Field label="Period" value={card.period} onChange={(v) => updateCardField(i, "period", v)} />
                  <Field label="Features (comma-separated)" value={card.features.join(", ")} onChange={(v) => updateCardField(i, "features", v.split(",").map((s) => s.trim()))} />
                  <Field label="WhatsApp Link" value={card.whatsappLink} onChange={(v) => updateCardField(i, "whatsappLink", v)} />
                  <label className="flex items-center gap-2 text-xs text-muted-foreground">
                    <input type="checkbox" checked={card.popular} onChange={(e) => updateCardField(i, "popular", e.target.checked)} className="accent-primary" />
                    Mark as Popular
                  </label>
                </ItemCard>
              ))}
            </Section>
          )}

          {tab === "faq" && (
            <Section title="FAQ" action={<AddBtn onClick={addFAQ} />}>
              <Field label="Section Title" value={draft.faq.sectionTitle} onChange={(v) => updateDraft("faq.sectionTitle", v)} />
              {draft.faq.items.map((item, i) => (
                <ItemCard key={item.id} label={`FAQ ${i + 1}`} onRemove={() => removeFAQ(item.id)}>
                  <Field label="Question" value={item.question} onChange={(v) => updateFAQField(i, "question", v)} />
                  <Field label="Answer" value={item.answer} onChange={(v) => updateFAQField(i, "answer", v)} textarea />
                </ItemCard>
              ))}
            </Section>
          )}

          {tab === "contact" && (
            <Section title="Contact Form Settings">
              <Field label="Section Title" value={draft.contact.sectionTitle} onChange={(v) => updateDraft("contact.sectionTitle", v)} />
              <Field label="Section Subtitle" value={draft.contact.sectionSubtitle} onChange={(v) => updateDraft("contact.sectionSubtitle", v)} textarea />
              <Field label="Recipient Email" value={draft.contact.recipientEmail} onChange={(v) => updateDraft("contact.recipientEmail", v)} />
            </Section>
          )}

          {tab === "navbar" && (
            <Section title="Navbar Settings" action={<AddBtn label="Add Link" onClick={() => addNavLink("navbar")} />}>
              <Field label="Login Button Text" value={draft.navbar.loginText} onChange={(v) => updateDraft("navbar.loginText", v)} />
              <Field label="Register Button Text" value={draft.navbar.registerText} onChange={(v) => updateDraft("navbar.registerText", v)} />
              <p className="text-xs text-muted-foreground font-medium mt-2">Navigation Links</p>
              {draft.navbar.links.map((link, i) => (
                <ItemCard key={link.id} label={link.label} onRemove={() => removeNavLink("navbar", link.id)}>
                  <Field label="Label" value={link.label} onChange={(v) => updateNavLink("navbar", i, "label", v)} />
                  <Field label="Link (href)" value={link.href} onChange={(v) => updateNavLink("navbar", i, "href", v)} />
                </ItemCard>
              ))}
            </Section>
          )}

          {tab === "footer" && (
            <Section title="Footer Settings" action={<AddBtn label="Add Link" onClick={() => addNavLink("footer")} />}>
              <Field label="Copyright Text" value={draft.footer.copyrightText} onChange={(v) => updateDraft("footer.copyrightText", v)} />
              <label className="flex items-center gap-2 text-xs text-muted-foreground">
                <input type="checkbox" checked={draft.footer.showBrand} onChange={(e) => updateDraft("footer.showBrand", e.target.checked)} className="accent-primary" />
                Show Brand Logo in Footer
              </label>
              <p className="text-xs text-muted-foreground font-medium mt-2">Footer Links</p>
              {draft.footer.links.map((link, i) => (
                <ItemCard key={link.id} label={link.label} onRemove={() => removeNavLink("footer", link.id)}>
                  <Field label="Label" value={link.label} onChange={(v) => updateNavLink("footer", i, "label", v)} />
                  <Field label="Link (href)" value={link.href} onChange={(v) => updateNavLink("footer", i, "href", v)} />
                </ItemCard>
              ))}
            </Section>
          )}

          {tab === "pages" && (
            <Section title="Custom Pages" action={<AddBtn label="Add Page" onClick={addPage} />}>
              <p className="text-xs text-muted-foreground">Create custom pages accessible at <code className="text-primary">/page/your-slug</code>. Toggle visibility in navbar and footer.</p>
              {draft.pages.length === 0 && <p className="text-sm text-muted-foreground italic">No custom pages yet.</p>}
              {draft.pages.map((page, i) => (
                <ItemCard key={page.id} label={page.title} onRemove={() => removePage(page.id)}>
                  <Field label="Page Title" value={page.title} onChange={(v) => updatePageField(i, "title", v)} />
                  <Field label="URL Slug" value={page.slug} onChange={(v) => updatePageField(i, "slug", v.toLowerCase().replace(/[^a-z0-9-]/g, "-"))} />
                  <Field label="Content (HTML)" value={page.content} onChange={(v) => updatePageField(i, "content", v)} textarea />
                  <div className="flex gap-4">
                    <label className="flex items-center gap-2 text-xs text-muted-foreground">
                      <input type="checkbox" checked={page.showInNav} onChange={(e) => updatePageField(i, "showInNav", e.target.checked)} className="accent-primary" />
                      Show in Navbar
                    </label>
                    <label className="flex items-center gap-2 text-xs text-muted-foreground">
                      <input type="checkbox" checked={page.showInFooter} onChange={(e) => updatePageField(i, "showInFooter", e.target.checked)} className="accent-primary" />
                      Show in Footer
                    </label>
                  </div>
                </ItemCard>
              ))}
            </Section>
          )}

          {tab === "theme" && (
            <Section title="Theme Colors">
              <p className="text-xs text-muted-foreground mb-4">Adjust the primary accent color used throughout the site.</p>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className={labelClass}>Hue (0-360)</label>
                  <input type="range" min="0" max="360" value={draft.theme.primaryHue} onChange={(e) => updateDraft("theme.primaryHue", Number(e.target.value))} className="w-full accent-primary" />
                  <span className="text-xs text-muted-foreground">{draft.theme.primaryHue}</span>
                </div>
                <div>
                  <label className={labelClass}>Saturation (%)</label>
                  <input type="range" min="0" max="100" value={draft.theme.primarySaturation} onChange={(e) => updateDraft("theme.primarySaturation", Number(e.target.value))} className="w-full accent-primary" />
                  <span className="text-xs text-muted-foreground">{draft.theme.primarySaturation}%</span>
                </div>
                <div>
                  <label className={labelClass}>Lightness (%)</label>
                  <input type="range" min="20" max="80" value={draft.theme.primaryLightness} onChange={(e) => updateDraft("theme.primaryLightness", Number(e.target.value))} className="w-full accent-primary" />
                  <span className="text-xs text-muted-foreground">{draft.theme.primaryLightness}%</span>
                </div>
              </div>
              <div className="mt-4 flex items-center gap-4">
                <div className="h-16 w-16 rounded-lg glow-orange" style={{ backgroundColor: `hsl(${draft.theme.primaryHue} ${draft.theme.primarySaturation}% ${draft.theme.primaryLightness}%)` }} />
                <span className="text-sm text-muted-foreground">Preview of your primary color</span>
              </div>
            </Section>
          )}
        </div>
      </div>
    </div>
  );
};

// Shared sub-components
const Section = ({ title, children, action }: { title: string; children: React.ReactNode; action?: React.ReactNode }) => (
  <div className="rounded-xl border border-border bg-gradient-card p-6 space-y-4">
    <div className="flex items-center justify-between">
      <h2 className="text-lg font-bold text-foreground">{title}</h2>
      {action}
    </div>
    {children}
  </div>
);

const Field = ({ label, value, onChange, textarea }: { label: string; value: string; onChange: (v: string) => void; textarea?: boolean }) => {
  const cls = "w-full rounded-lg border border-border bg-background px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary";
  return (
    <div>
      <label className="block text-xs font-medium text-muted-foreground mb-1.5">{label}</label>
      {textarea ? <textarea value={value} onChange={(e) => onChange(e.target.value)} rows={3} className={`${cls} resize-none`} /> : <input type="text" value={value} onChange={(e) => onChange(e.target.value)} className={cls} />}
    </div>
  );
};

const AddBtn = ({ label = "Add", onClick }: { label?: string; onClick: () => void }) => (
  <button onClick={onClick} className="flex items-center gap-1 text-xs text-primary hover:opacity-80"><Plus className="h-3.5 w-3.5" /> {label}</button>
);

const ItemCard = ({ label, onRemove, children }: { label: string; onRemove: () => void; children: React.ReactNode }) => (
  <div className="rounded-lg border border-border p-4 space-y-3">
    <div className="flex items-center justify-between">
      <span className="text-xs font-medium text-foreground">{label}</span>
      <button onClick={onRemove} className="text-muted-foreground hover:text-destructive"><Trash2 className="h-3.5 w-3.5" /></button>
    </div>
    {children}
  </div>
);

export default Admin;
