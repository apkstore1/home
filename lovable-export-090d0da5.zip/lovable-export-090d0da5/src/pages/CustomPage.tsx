import { useParams } from "react-router-dom";
import { useConfig } from "@/contexts/ConfigContext";
import Navbar from "@/components/landing/Navbar";
import Footer from "@/components/landing/Footer";

const CustomPage = () => {
  const { slug } = useParams<{ slug: string }>();
  const { config } = useConfig();
  const page = config.pages.find((p) => p.slug === slug);

  if (!page) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 pt-32 pb-20 text-center">
          <h1 className="text-3xl font-bold text-foreground">Page Not Found</h1>
          <p className="mt-2 text-muted-foreground">This page doesn't exist.</p>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto px-4 pt-32 pb-20">
        <h1 className="text-3xl font-bold text-foreground mb-6">{page.title}</h1>
        <div
          className="prose prose-invert max-w-none text-muted-foreground [&_h2]:text-foreground [&_h3]:text-foreground [&_strong]:text-foreground [&_a]:text-primary"
          dangerouslySetInnerHTML={{ __html: page.content }}
        />
      </div>
      <Footer />
    </div>
  );
};

export default CustomPage;
